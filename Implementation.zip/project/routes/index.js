var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/login', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page2.html');
});
router.get('/user/register', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page3.html');
});
router.get('/user/edit', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page5.html');
});
router.get('/chechin', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page4.html');
});
router.get('/chechin/history', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page6.html');
});
router.get('/admin/edit', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page5.html');
});
router.get('/admin/map', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page10.html');
});
router.get('/admin/Search', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page11.html');
});
router.get('/admin/user_checkin_history', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page13.html');
});
router.get('/admin/venue_checkin_history', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page12.html');
});
router.get('/admin/sign_up', function(req, res, next) {
  //res.render('index', { title: 'Express' });
  res.redirect('../page16.html');
});


module.exports = router;
